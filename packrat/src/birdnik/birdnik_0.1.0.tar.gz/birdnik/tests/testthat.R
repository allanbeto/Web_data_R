library(testthat)
library(birdnik)

test_check("birdnik")
